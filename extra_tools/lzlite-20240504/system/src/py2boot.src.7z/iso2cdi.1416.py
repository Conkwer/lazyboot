#!/usr/bin/env python3

import sys
import os
import zlib
import base64

lba=11702

tdi=b'''
eJzt1r+Lz3EcwPHPfWNCKVlMfpQVu8JlMZDBDWeSK4tYXSndopTx/gOD4QxkuY1FGVwd62
WwMon79rV9lSvdMyw3MHg86j283r179R6fw3B4GH4cAADOHHj2YtBHAAA/6SMAgNJHAACl
jwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6SMAgNJHAACljwAASh8BAJQ+AgAofQQAUPoIAK
D0EQBA6SMAgNJHAACljwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6SMAgNJHAACljwAASh8B
AJQ+AgAofQQAUPoIAKD0EQBA6SMAgNJHAACljwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6S
MAgNJHAACljwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6SMAgNJHAACljwAASh8BAJQ+AgAo
fQQAUPoIAKD0EQBA6SMAgNJHAACljwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6SMAgNJHAA
CljwAASh8BAJQ+AgAofQQAUPoIAKD0EQBA6SMAgNrqoy1Xzl+YuTwzGo2WptPpv/wUAPDX
LF4/cmv7vLx4f3xtPJlM9qysrOx464PHC6vb59en1zZPbo7H44dzc3M73vr51exGbxZW30
7mj3+6MQzvhq8HL46/nbp34ubauaUPX46d/dOW2Y03R5evHno0DHeHvS/3P9n9/OPT9+uX
9t1ev7Pr19f6CAD+P/pIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/
0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAK
WP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfA
QClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpI
HwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD
6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQ
BQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9
BEAUPpIHwEApY/0EQBQ+kgfAQClj/QRAFD6SB8BAKWP9BEAUPpIHwEApY9+30ffATBSXmU='''

end=b'''
eJxjYFBgYADjUTAKRsEoGAWjYBSMglFgL7xhH8No+2gUjIJRMApGwSgYBaMADkDtIyYGRigP
RP8HAgRrNYMAEwcWfUwIZoNDHSuQmgEUmwak9RixKIeDI1hkmfBJgsF/KADJN0B1CACxyxp8
dmEzBackNYMghA1dDcz0E+sZGF6xMWAAkDwLiIFNEu546gcBzH0gd6E4hvwgWGACbGsTAmCT
8SYUEACGRcNCoB0AWgtNAw=='''



f=open(sys.argv[1],'rb')
f.seek(0,2)
lg=f.tell()
sz=int(lg/2048)
f.seek(0)

print('Please wait...')

g=open('image.cdi','wb')
g.write(bytes(1063104))
temp=zlib.decompress(base64.b64decode(tdi))
g.write(temp)

for i in range(0,sz,1):
    temp=f.read(0x800)
    g.write(b'\x00'*8)
    g.write(temp)
    g.write(b'\x00'*280)

temp=zlib.decompress(base64.b64decode(end))
g.write(temp)

g.seek(-158,2)
g.write(lba.to_bytes(4,'little'))
g.seek(-277,2)
g.write((sz+152).to_bytes(4,'little'))
g.seek(-310,2)
g.write(lba.to_bytes(4,'little'))
g.write((sz+152).to_bytes(4,'little'))
g.seek(-336,2)
g.write((sz+2).to_bytes(4,'little'))
g.close()

# input('Process completed!!! Press ENTER key...')





